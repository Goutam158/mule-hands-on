package com.demo;
 import static java.util.Objects.nonNull;

import java.util.Arrays;
import java.util.List;

public class StringAppender {
 
	 public static String appender (String arr [])
	 {
		 String retStr = null;
		  if (nonNull(arr) && arr.length > 0)
		  {
			  List<String> listOfString = Arrays.asList(arr);
			   retStr = listOfString.isEmpty() ? "" : "\"" + String.join("\", \"", listOfString) + "\"";
		  }
		 return retStr;
	 }
	 
		/*
		 * public static void main(String[] args) { String [] strArr =
		 * {"type1","type2","type3"}; System.out.println(appender(strArr)); }
		 */
}
